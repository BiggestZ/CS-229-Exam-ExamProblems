/**
 * This class represents a Stack in the linked list implementation.
 * Each Stack contains a reference to the top node and the stack size.
 * @author celiachen
 *
 */
public class Stack {
	public LinkedNode topNode;
	public int size;
	
	/**
	 * Construct a new Stack.
	 */
	public Stack(){
		topNode = null;
		size = 0;
	}
	
	/**
	 * Returns true if this Stack is empty.
	 * @return true
	 */
	public boolean isEmpty(){
		if (size==0){
			return true;
		}
		else
			return false;
	}
	
	/**
	 * Returns the number of LinkedNode in this Stack.
	 * @return int
	 */
	public int size(){
		return size;
	}
	
	
	/**
	 * Adds the specified LinkedNode to the end of this stack.
	 * @param node The LinkedNode needs to be pushed 
	 */
	
	public void push(int value){
		LinkedNode node = new LinkedNode(value);

		node.nextNode = topNode;
		topNode = node;
		size++;
	}
	
	
	/**
	 * Removes the most recent added LinkedNode from the stack.
	 * @return The most recent added LinkedNode
	 */
	public LinkedNode pop(){
		LinkedNode returnNode = null;
		if (size>0){
			returnNode = topNode;
			topNode = topNode.nextNode;
			size--;
		}
		return returnNode;
	}
	
	public String toString() {
		String str = " ";
		return str;
	}
	
	
}
