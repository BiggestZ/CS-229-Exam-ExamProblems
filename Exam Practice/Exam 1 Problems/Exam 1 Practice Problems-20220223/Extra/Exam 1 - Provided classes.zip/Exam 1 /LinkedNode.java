
public class LinkedNode {
	int value; 
	LinkedNode nextNode;
	
	/**
	 * Construct a new LinkedNode with a specific value.
	 * @param value An integer value to be put into a new LinkedNode
	 */
	public LinkedNode(int value) {
		this.value = value;
		this.nextNode = null;
	}
	
}
