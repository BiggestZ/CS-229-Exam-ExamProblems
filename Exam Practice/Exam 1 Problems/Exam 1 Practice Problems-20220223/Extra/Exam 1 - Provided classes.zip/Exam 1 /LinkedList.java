
public class LinkedList {
	LinkedNode head;
	
	/**
	 * Constructs an empty list.
	 */
	
	public LinkedList() {
		this.head = null;
	}

	/**
	 * Returns the number of LinkedNodes in this list.
	 * @return the number of LinkedNodes in this list
	 */
	
	public int size() {
		if (isEmpty()) {
			return 0;
		}
		else {
			LinkedNode currentNode = this.head;
			int size = 1;
			// initialization of the variable
			// test for condition
			// change the variable
			
			while (currentNode.nextNode!= null) {
				// add 1 to size
				size ++;
				currentNode = currentNode.nextNode;
			}
			return size;
		}
	}
		
	/**
	 * Returns true if this list is empty. 
	 * @return true
	 */
	
	public boolean isEmpty() {
		return this.head == null;
	}
	
	/**
	 * Adds the specified LinkedNode to the end of this list.
	 * @return true
	 * @param insertValue The value to be inserted into this list
	 */
	public boolean insert(int insertValue) {
		LinkedNode newNode = new LinkedNode(insertValue);
		boolean hasInserted = false;
		if (head == null) {
			this.head = newNode;
			hasInserted = true;
		}
		else {
			LinkedNode start = this.head;
			while (start.nextNode != null) {
				start = start.nextNode;
			}
			start.nextNode = newNode;
			hasInserted = true;
		}
		return hasInserted;
	}
	
	/**
	 * Inserts the specified LinkedNode at the specified position in this list. Shifts the LinkedNode currently at that position (if any) and any subsequent LinkedNodes to the right (adds one to their indices).
	 * @param insertValue The value to be inserted into this list
	 * @param i The position
	 * @throws IndexOutOfBoundsException - if the index is out of range
	 */
	public void insert(int insertValue, int i) {
		if ( i < 0 || i >= size()) {
		
			//System.out.println(i + " : " + size());
			System.out.println("Index is out of range.");
		}
		else if (i == 0) {
			LinkedNode newNode = new LinkedNode(insertValue);
			LinkedNode temp = this.head;
			this.head = newNode;
			newNode.nextNode = temp;
		}
		else {
			LinkedNode currentNode = this.head;
			LinkedNode newNode = new LinkedNode(insertValue);
			int count = 0;
			while (count < i-1) {
				currentNode = currentNode.nextNode;
				count++;
			}
			
			// 1 2 3 4
			// 1 2 5 3 4
			LinkedNode temp = currentNode.nextNode;
			currentNode.nextNode = newNode;
			newNode.nextNode = temp;
			// temp = current.next
			// current.next = new node
			// new node.next = temp
			
		}
	}
	
	/**
	 * Removes the LinkedNode at the specified position in this list. Shifts any subsequent LinkedNodes to the left (subtracts one from their indices). Returns the LinkedNode that was removed from the list.
	 * @param i The position
	 * @return the LinkedNode previously at the specified position
	 * @throws IndexOutOfBoundsException - if the index is out of range
	 */
	public LinkedNode remove(int i) {
		if (i < 0 || i >= size()) {
			System.out.println("Index is out of range.");
			return null;
		}
		else if (i == 0) {
			LinkedNode removed = this.head;
			this.head = this.head.nextNode;
			return removed;
		}
		else {
			LinkedNode currentNode = this.head;
			int count = 0;
			while (count < i-1) {
				currentNode = currentNode.nextNode;
				count ++;
			}
			LinkedNode removed = currentNode.nextNode;
			currentNode.nextNode = currentNode.nextNode.nextNode; 
			return removed;
			// 1 2 3 4 5 remove 2, stop at 1, 1.next will be removed and returned, 1.next becomes 1.next.next
			// 1 2 4 5 
			
		}
	}
	
	/**
	 * Returns true if this list contains at least one specified LinkedNode with the value.
	 * @param value The value to be searched from this list
	 * @return true
	 */
	public boolean contains(int value) {
		
		LinkedNode currentNode = this.head;
		while (currentNode != null) {
			if (currentNode.value == value) {
				return true;
			}
			currentNode = currentNode.nextNode;
		}
		return false;
		
	}
	
	/**
	 * Returns a string representation of the list.
	 * Here is an example of the string representation of a list:
	 * [ 2, 4, 0 ]
	 */
	
	public String toString() {
		String str= " [ ";
		LinkedNode currentNode = this.head;
		
		while (currentNode != null) {
			str = str + currentNode.value;
			
			if (currentNode.nextNode != null) {
				
				str = str + ", ";
			}
			currentNode = currentNode.nextNode;
		}
		str = str + " ] ";
		return str;
	}
}