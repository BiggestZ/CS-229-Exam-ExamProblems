/**
 * This class represents a Queue in the linked list implementation.
 * Each Queue contains a reference to the first node, a reference to the last node, and the size of the Queue.
 * @author celiachen
 *
 */
public class Queue {
		public LinkedNode firstNode;
		public LinkedNode lastNode;
		public int size;
		
	/**
	 * Constructs an empty Queue.
	 */
		public Queue(){
			firstNode = null;
			lastNode = null;
			size = 0;
		}
		
		/**
		 * Returns true if this Queue is empty.
		 * @return true
		 */
		public boolean isEmpty(){
			if (size==0){
				return true;
			}
			else
				return false;
		}
		
		/**
		 * Returns the number of LinkedNode in this Queue.
		 * @return int
		 */
		public int size(){
			return size;
		}
		
		
		/**
		 * Enqueues a LinkedNode onto the end of the Queue.
		 * @param node The LinkedNode needs to be enqueued
		 */
		
		public void enqueue(int value){
			LinkedNode node = new LinkedNode(value);
			if (size==0){
				firstNode = node;
				lastNode = node;
			}
			else{
				lastNode.nextNode = node;
				lastNode = node;
			}
			size++;
		}
		
		
		/**
		 * Removes the LinkedNode that was inserted first.
		 * @return The removed LinkedNode
		 */
		public LinkedNode dequeue(){
			LinkedNode returnNode = null;
			if (size>0){
				returnNode = firstNode;
				firstNode = firstNode.nextNode;
				size--;
			}
			
			return returnNode;
		}
		
}
